package cool.structures;

public class FeatureSymbol extends Symbol {
    FeatureSymbol(String name) {
        super(name);
    }
}
